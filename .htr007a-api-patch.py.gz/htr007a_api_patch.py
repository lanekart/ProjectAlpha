from __future__ import annotations

from pathlib import Path
from textwrap import dedent


def replace_once(source: str, old: str, new: str) -> str:
    if old not in source:
        raise RuntimeError(f"expected source fragment not found: {old[:160]!r}")
    return source.replace(old, new, 1)


source_path = Path("alpha/historical_truth/historical_session_evidence_audit.py")
source = source_path.read_text(encoding="utf-8")

source = replace_once(
    source,
    'NSE_CIRCULAR_DIRECTORY = "https://www.nseindia.com/static/list-circulars"\n',
    'NSE_CIRCULARS_API = "https://www.nseindia.com/api/circulars"\n'
    'NSE_CIRCULAR_DIRECTORY = "https://www.nseindia.com/static/list-circulars"\n',
)
source = replace_once(
    source,
    '    HTML_PARSE_FAILED = "HTML_PARSE_FAILED"\n',
    '    HTML_PARSE_FAILED = "HTML_PARSE_FAILED"\n'
    '    JSON_PARSE_FAILED = "JSON_PARSE_FAILED"\n',
)
source = replace_once(
    source,
    'class DocumentParser(StrEnum):\n'
    '    PDF = "pdf"\n'
    '    HTML = "html"\n'
    '    TEXT = "text"\n',
    'class DocumentParser(StrEnum):\n'
    '    PDF = "pdf"\n'
    '    HTML = "html"\n'
    '    JSON = "json"\n'
    '    TEXT = "text"\n',
)
source = replace_once(
    source,
    '        pages = (\n'
    '            ("nse_holiday_directory", f"{NSE_HOLIDAY_DIRECTORY}?year={year}"),\n'
    '            ("nse_circular_directory", NSE_CIRCULAR_DIRECTORY),\n'
    '        )\n',
    '        circular_api_url = (\n'
    '            f"{NSE_CIRCULARS_API}?from_date=01-10-{year - 1}"\n'
    '            f"&to_date=31-03-{year}&dept=CMTR&sub=holiday"\n'
    '        )\n'
    '        pages = (\n'
    '            ("nse_circulars_api", circular_api_url),\n'
    '            ("nse_holiday_directory", f"{NSE_HOLIDAY_DIRECTORY}?year={year}"),\n'
    '            ("nse_circular_directory", NSE_CIRCULAR_DIRECTORY),\n'
    '        )\n',
)
source = replace_once(
    source,
    '            links = self.discover_documents(\n'
    '                page.raw.decode("utf-8", errors="replace"), page.url, year\n'
    '            )\n'
    '            if not links:\n'
    '                self.attempts.append(\n'
    '                    self._failed_attempt(\n'
    '                        year,\n'
    '                        f"{family}:discovery",\n'
    '                        page.url,\n'
    '                        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '                        "no official Capital Market holiday attachment discovered",\n'
    '                    )\n'
    '                )\n',
    '            try:\n'
    '                links = (\n'
    '                    self.discover_api_documents(page.raw, year)\n'
    '                    if page.parser is DocumentParser.JSON\n'
    '                    else self.discover_documents(\n'
    '                        page.raw.decode("utf-8", errors="replace"),\n'
    '                        page.url,\n'
    '                        year,\n'
    '                    )\n'
    '                )\n'
    '            except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:\n'
    '                self._finish_discovery(page, error=exc)\n'
    '                continue\n'
    '            if not links:\n'
    '                self._finish_discovery(\n'
    '                    page,\n'
    '                    error=ValueError(\n'
    '                        "no official Capital Market holiday attachment discovered"\n'
    '                    ),\n'
    '                    failure_code=AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '                )\n'
    '                continue\n'
    '            self._finish_discovery(page, records_inspected=len(links))\n',
)
source = replace_once(
    source,
    '        content_type = str(response_headers.get("Content-Type", "")).split(";", 1)[0]\n',
    '        content_type = str(\n'
    '            response_headers.get("Content-Type")\n'
    '            or response_headers.get("content-type")\n'
    '            or ""\n'
    '        ).split(";", 1)[0]\n',
)
source = replace_once(
    source,
    '        if raw.startswith(b"%PDF"):\n'
    '            return DocumentParser.PDF, ".pdf"\n'
    '        if sample.startswith((b"<!doctype html", b"<html", b"<table")):\n',
    '        if raw.startswith(b"%PDF"):\n'
    '            return DocumentParser.PDF, ".pdf"\n'
    '        if sample.startswith((b"{", b"[")) or "json" in content_type.lower():\n'
    '            return DocumentParser.JSON, ".json"\n'
    '        if sample.startswith((b"<!doctype html", b"<html", b"<table")):\n',
)
source = replace_once(
    source,
    '        return tuple(dict.fromkeys(found))\n\n'
    '    @classmethod\n'
    '    def _parse(cls, document: _Document, year: int) -> ParsedAnnualCalendar:\n',
    '        return tuple(dict.fromkeys(found))\n\n'
    '    @staticmethod\n'
    '    def discover_api_documents(raw: bytes, year: int) -> tuple[str, ...]:\n'
    '        payload = json.loads(raw.decode("utf-8"))\n'
    '        if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):\n'
    '            raise ValueError("official circular response does not contain a data list")\n'
    '        found: list[str] = []\n'
    '        for item in payload["data"]:\n'
    '            if not isinstance(item, dict):\n'
    '                continue\n'
    '            department = str(item.get("fileDept", "")).upper()\n'
    '            subject = str(item.get("sub", ""))\n'
    '            link = str(item.get("circFilelink", "")).strip()\n'
    '            extension = str(item.get("fileExt", "")).lower().lstrip(".")\n'
    '            host = (urlparse(link).hostname or "").lower()\n'
    '            if department != "CMTR":\n'
    '                continue\n'
    '            if "holiday" not in subject.lower() or str(year) not in subject:\n'
    '                continue\n'
    '            if extension not in {"pdf", "htm", "html"}:\n'
    '                continue\n'
    '            if not HistoricalSessionEvidenceRepairEngine._official_host(host):\n'
    '                continue\n'
    '            found.append(link)\n'
    '        return tuple(dict.fromkeys(found))\n\n'
    '    @classmethod\n'
    '    def _parse(cls, document: _Document, year: int) -> ParsedAnnualCalendar:\n',
)
source = replace_once(
    source,
    '    def _finish_attempt(\n',
    '    def _finish_discovery(\n'
    '        self,\n'
    '        document: _Document,\n'
    '        *,\n'
    '        records_inspected: int = 0,\n'
    '        error: Exception | None = None,\n'
    '        failure_code: AcquisitionFailureCode | None = None,\n'
    '    ) -> None:\n'
    '        for index in range(len(self.attempts) - 1, -1, -1):\n'
    '            item = self.attempts[index]\n'
    '            if item.final_url != document.url or item.evidence_status != "candidate":\n'
    '                continue\n'
    '            if error is None:\n'
    '                self.attempts[index] = replace(\n'
    '                    item,\n'
    '                    records_inspected=records_inspected,\n'
    '                    parse_status="parsed",\n'
    '                    evidence_status="discovery_only",\n'
    '                )\n'
    '            else:\n'
    '                self.attempts[index] = replace(\n'
    '                    item,\n'
    '                    parse_status="failed",\n'
    '                    evidence_status="rejected",\n'
    '                    failure_code=failure_code\n'
    '                    or self._parse_failure(error, document.parser),\n'
    '                    failure_detail=f"{type(error).__name__}: {error}",\n'
    '                )\n'
    '            return\n\n'
    '    def _finish_attempt(\n',
)
source = replace_once(
    source,
    '        if "no extractable text" in text:\n'
    '            return AcquisitionFailureCode.NO_SESSION_RECORDS_FOUND\n'
    '        return (\n',
    '        if "no extractable text" in text:\n'
    '            return AcquisitionFailureCode.NO_SESSION_RECORDS_FOUND\n'
    '        if parser is DocumentParser.JSON:\n'
    '            return AcquisitionFailureCode.JSON_PARSE_FAILED\n'
    '        return (\n',
)
source_path.write_text(source, encoding="utf-8")


tests_path = Path("tests/historical_truth/test_historical_session_evidence_audit.py")
tests = tests_path.read_text(encoding="utf-8")
tests = replace_once(
    tests,
    "    NSE_CIRCULAR_DIRECTORY,\n",
    "    NSE_CIRCULARS_API,\n    NSE_CIRCULAR_DIRECTORY,\n",
)
failed_setup = (
    '    holiday_page = f"{NSE_HOLIDAY_DIRECTORY}?year={year}"\n'
    '    session = _Session(\n'
    '        {\n'
    '            holiday_page: _Response(b"missing", status_code=404, url=holiday_page),\n'
    '            NSE_CIRCULAR_DIRECTORY: _Response(\n'
)
failed_setup_with_api = (
    '    holiday_page = f"{NSE_HOLIDAY_DIRECTORY}?year={year}"\n'
    '    api_url = (\n'
    '        f"{NSE_CIRCULARS_API}?from_date=01-10-{year - 1}"\n'
    '        f"&to_date=31-03-{year}&dept=CMTR&sub=holiday"\n'
    '    )\n'
    '    session = _Session(\n'
    '        {\n'
    '            api_url: _Response(b"missing", status_code=404, url=api_url),\n'
    '            holiday_page: _Response(b"missing", status_code=404, url=holiday_page),\n'
    '            NSE_CIRCULAR_DIRECTORY: _Response(\n'
)
tests = replace_once(tests, failed_setup, failed_setup_with_api)
tests = replace_once(
    tests,
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '    ]\n',
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '        AcquisitionFailureCode.OFFICIAL_DOCUMENT_NOT_FOUND,\n'
    '    ]\n',
)
tests = replace_once(tests, failed_setup, failed_setup_with_api)
tests_path.write_text(tests, encoding="utf-8")


api_test_path = Path("tests/historical_truth/test_historical_session_evidence_api.py")
api_test_path.write_text(
    dedent(
        '''
        from __future__ import annotations

        import json
        from pathlib import Path
        from typing import Any

        import pytest

        from alpha.historical_truth.historical_session_evidence import (
            HistoricalEvidenceRecord,
            HistoricalEvidenceStatus,
            HistoricalSessionEvidenceEngine,
        )
        from alpha.historical_truth.historical_session_evidence_audit import (
            NSE_CIRCULARS_API,
            DocumentParser,
            HistoricalSessionEvidenceRepairEngine,
        )


        class _Response:
            def __init__(
                self,
                content: bytes,
                *,
                status_code: int = 200,
                url: str = "",
                content_type: str = "application/octet-stream",
            ) -> None:
                self.content = content
                self.status_code = status_code
                self.url = url
                self.headers = {"Content-Type": content_type}
                self.history: tuple[object, ...] = ()


        class _Session:
            def __init__(self, responses: dict[str, _Response]) -> None:
                self.responses = responses
                self.calls: list[str] = []

            def get(self, url: str, **_: Any) -> _Response:
                self.calls.append(url)
                return self.responses[url]


        def _failed_record(year: int) -> HistoricalEvidenceRecord:
            return HistoricalEvidenceRecord(
                year=year,
                status=HistoricalEvidenceStatus.FAILED,
                year_page_url=(
                    f"https://www.nseindia.com/static/holidays-for-the-calendar-year-{year}"
                ),
                year_page_path=None,
                year_page_sha256=None,
                circular_url=None,
                circular_path=None,
                circular_sha256=None,
                normalized_path=None,
                normalized_sha256=None,
                holiday_count=0,
                special_session_count=0,
                error="RuntimeError: HTTP 404",
            )


        def _annual_text(year: int) -> str:
            return f"""
            Capital Market (Equities)
            Trading holidays for the calendar year {year}
            1 26-January-{year} Republic Day
            2 08-March-{year} Festival
            3 25-March-{year} Festival
            4 29-March-{year} Festival
            5 11-April-{year} Festival
            6 17-April-{year} Festival
            7 01-May-{year} Maharashtra Day
            8 17-June-{year} Festival
            9 15-August-{year} Independence Day
            10 02-October-{year} Gandhi Jayanti
            11 01-November-{year} Diwali Laxmi Pujan
            12 25-December-{year} Christmas
            The holidays falling on Saturday / Sunday are as follows
            Muhurat Trading will be conducted on November 01, {year}.
            """


        def _api_url(year: int) -> str:
            return (
                f"{NSE_CIRCULARS_API}?from_date=01-10-{year - 1}"
                f"&to_date=31-03-{year}&dept=CMTR&sub=holiday"
            )


        def test_json_content_is_identified_before_filename() -> None:
            parser, extension = HistoricalSessionEvidenceRepairEngine.inspect_content(
                b'{"data": []}',
                "text/plain",
                "https://www.nseindia.com/api/circulars",
            )
            assert parser is DocumentParser.JSON
            assert extension == ".json"


        def test_api_discovery_filters_to_official_cmtr_year() -> None:
            official = "https://nsearchives.nseindia.com/content/circulars/CMTR123.pdf"
            payload = json.dumps(
                {
                    "data": [
                        {
                            "fileDept": "CMTR",
                            "fileExt": "pdf",
                            "sub": "Trading holidays for the calendar year 2024",
                            "circFilelink": official,
                        },
                        {
                            "fileDept": "FAO",
                            "fileExt": "pdf",
                            "sub": "Trading holidays for the calendar year 2024",
                            "circFilelink": (
                                "https://nsearchives.nseindia.com/content/circulars/FAO1.pdf"
                            ),
                        },
                        {
                            "fileDept": "CMTR",
                            "fileExt": "pdf",
                            "sub": "Trading holidays for the calendar year 2024",
                            "circFilelink": "https://example.com/CMTR999.pdf",
                        },
                    ]
                }
            ).encode()
            assert HistoricalSessionEvidenceRepairEngine.discover_api_documents(
                payload, 2024
            ) == (official,)


        def test_api_fallback_admits_official_legacy_year(
            tmp_path: Path,
            monkeypatch: pytest.MonkeyPatch,
        ) -> None:
            year = 2024
            api_url = _api_url(year)
            attachment = "https://nsearchives.nseindia.com/content/circulars/CMTR123.pdf"
            payload = json.dumps(
                {
                    "data": [
                        {
                            "fileDept": "CMTR",
                            "fileExt": "pdf",
                            "sub": f"Trading holidays for the calendar year {year}",
                            "circFilelink": attachment,
                        }
                    ]
                }
            ).encode()
            session = _Session(
                {
                    api_url: _Response(
                        payload, url=api_url, content_type="application/json"
                    ),
                    attachment: _Response(
                        b"%PDF-fixture",
                        url=attachment,
                        content_type="application/pdf",
                    ),
                }
            )
            monkeypatch.setattr(
                HistoricalSessionEvidenceEngine,
                "acquire_year",
                lambda self, requested_year, **kwargs: _failed_record(requested_year),
            )
            monkeypatch.setattr(
                HistoricalSessionEvidenceRepairEngine,
                "extract_pdf_text",
                staticmethod(lambda _: _annual_text(year)),
            )
            engine = HistoricalSessionEvidenceRepairEngine(tmp_path / "alpha_data")

            record = engine.acquire_year_repaired(year, session=session)

            assert record.status is HistoricalEvidenceStatus.COMPLETE
            assert record.circular_url == attachment
            assert session.calls[:2] == [api_url, attachment]
            assert any(
                item.source_family == "nse_circulars_api:attachment"
                and item.evidence_status == "admitted"
                for item in engine.attempts
            )
        '''
    ).lstrip(),
    encoding="utf-8",
)


docs_path = Path(
    "docs/HTR-007A_HISTORICAL_SESSION_EVIDENCE_ACQUISITION_AUDIT.md"
)
docs = docs_path.read_text(encoding="utf-8")
marker = "## Official circular API fallback"
if marker not in docs:
    docs += (
        "\n## Official circular API fallback\n\n"
        "Failed annual-page acquisitions are retried through the official NSE "
        "`/api/circulars` endpoint with `dept=CMTR`, a holiday subject filter, "
        "and a governed October-to-March discovery window. API discovery remains "
        "candidate-only until the attachment passes official-host, year, segment, "
        "content, parser, and immutable-checksum admission gates.\n"
    )
docs_path.write_text(docs, encoding="utf-8")
