"""Project Alpha version information."""

from __future__ import annotations

__version__ = "1.2.0"